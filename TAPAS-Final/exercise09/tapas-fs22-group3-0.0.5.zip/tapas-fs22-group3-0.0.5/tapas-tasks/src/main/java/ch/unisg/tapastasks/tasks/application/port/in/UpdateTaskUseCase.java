package ch.unisg.tapastasks.tasks.application.port.in;

public interface UpdateTaskUseCase {
    Boolean updateTask(UpdateTaskCommand command);
}
