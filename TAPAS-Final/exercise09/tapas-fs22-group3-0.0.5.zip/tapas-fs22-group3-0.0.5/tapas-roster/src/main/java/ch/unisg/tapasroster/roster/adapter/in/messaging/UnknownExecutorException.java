package ch.unisg.tapasroster.roster.adapter.in.messaging;

public class UnknownExecutorException extends RuntimeException {

}
