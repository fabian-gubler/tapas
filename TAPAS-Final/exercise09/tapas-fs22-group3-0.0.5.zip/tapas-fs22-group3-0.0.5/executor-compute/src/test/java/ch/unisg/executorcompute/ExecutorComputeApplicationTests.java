package ch.unisg.executorcompute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExecutorComputeApplicationTests {

	@Test
	void contextLoads() {
	}

}
