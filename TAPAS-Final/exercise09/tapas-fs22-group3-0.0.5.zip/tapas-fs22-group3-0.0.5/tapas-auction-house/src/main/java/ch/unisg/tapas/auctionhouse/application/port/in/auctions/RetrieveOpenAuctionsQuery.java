package ch.unisg.tapas.auctionhouse.application.port.in.auctions;

/**
 * Query used to retrieve open auctions. Although this query is empty, we model it to convey the
 * domain semantics and to reduce coupling.
 */
public class RetrieveOpenAuctionsQuery {  }
