package ch.unisg.tapastasks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TapasTasksApplicationTests {

    @Test
	void contextLoads() {

	}

}
