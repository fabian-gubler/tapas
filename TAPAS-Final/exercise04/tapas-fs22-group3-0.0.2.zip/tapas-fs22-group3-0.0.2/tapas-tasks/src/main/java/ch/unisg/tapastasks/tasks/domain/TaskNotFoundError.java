package ch.unisg.tapastasks.tasks.domain;

public class TaskNotFoundError extends Exception { }
