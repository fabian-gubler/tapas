package ch.unisg.tapastasks.tasks.application.port.in;

public interface AddNewTaskToTaskListUseCase {
    String addNewTaskToTaskList(AddNewTaskToTaskListCommand command);
}
