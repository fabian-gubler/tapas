package ch.unisg.tapastasks.tasks.adapter.in.messaging;

public class UnknownEventException extends RuntimeException { }
