package ch.unisg.executorcompute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExecutorComputeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExecutorComputeApplication.class, args);
	}

}
