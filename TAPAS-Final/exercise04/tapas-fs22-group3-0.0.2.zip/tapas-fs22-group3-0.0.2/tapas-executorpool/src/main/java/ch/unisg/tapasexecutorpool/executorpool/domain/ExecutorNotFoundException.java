package ch.unisg.tapasexecutorpool.executorpool.domain;

public class ExecutorNotFoundException extends RuntimeException { }
