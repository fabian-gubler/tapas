package ch.unisg.tapasexecutorpool.executorpool.domain;

public class ExecutorNotFoundError extends Exception{}
