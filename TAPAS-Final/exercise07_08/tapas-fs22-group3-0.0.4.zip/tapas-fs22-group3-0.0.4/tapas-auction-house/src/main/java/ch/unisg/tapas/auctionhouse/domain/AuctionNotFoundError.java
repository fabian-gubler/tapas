package ch.unisg.tapas.auctionhouse.domain;

public class AuctionNotFoundError extends Exception { }
