package ch.unisg.tapasroster.roster.domain;

public class RosterNotFoundError extends Exception{}
