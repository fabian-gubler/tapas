package ch.unisg.tapasroster;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TapasRosterApplicationsTests {
}
