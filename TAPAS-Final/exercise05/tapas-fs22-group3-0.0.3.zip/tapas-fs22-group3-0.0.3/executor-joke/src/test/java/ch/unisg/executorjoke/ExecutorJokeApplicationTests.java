package ch.unisg.executorjoke;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExecutorJokeApplicationTests {

	@Test
	void contextLoads() {
	}

}
