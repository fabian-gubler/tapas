package ch.unisg.tapasroster.roster.domain;

public class RosterNotFoundException extends RuntimeException { }
