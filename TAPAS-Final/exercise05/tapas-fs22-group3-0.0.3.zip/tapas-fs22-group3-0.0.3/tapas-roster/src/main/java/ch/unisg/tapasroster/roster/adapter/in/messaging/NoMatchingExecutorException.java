package ch.unisg.tapasroster.roster.adapter.in.messaging;

public class NoMatchingExecutorException extends RuntimeException{

    public NoMatchingExecutorException(String message) {
        super(message);
    }
}
