package ch.unisg.tapastasks.tasks.domain;

public class TaskNotFoundException extends RuntimeException { }
